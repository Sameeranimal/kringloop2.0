<?php
/*
Versie: 1.0
Datum: 28 januari 2026
Beschrijving: Login pagina voor Kringloop Centrum Duurzaam
*/
 
require_once 'config.php';
require_once 'classes/Database.php';
require_once 'classes/User.php';
 
// Als al ingelogd, ga naar dashboard
$database = new Database();
$user = new User($database);
 
if($user->isIngelogd()) {
    header('Location: dashboard.php');
    exit();
}
 
$foutmelding = "";
 
// Als formulier verstuurd is
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
   
    $resultaat = $user->login($username, $password);
   
    if($resultaat === true) {
        header('Location: dashboard.php');
        exit();
    } else {
        $foutmelding = $resultaat;
    }
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inloggen - Kringloop Centrum Duurzaam</title>
</head>
<body>
    <div class="login-container">
        <div class="logo">
            <h1>Kringloop Centrum Duurzaam</h1>
            <p>Login systeem</p>
        </div>
        
        <?php if($foutmelding): ?>
            <div class="error"><?php echo $foutmelding; ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="username">Gebruikersnaam:</label>
                <input type="text" id="username" name="username" required>
            </div>
            
            <div class="form-group">
                <label for="password">Wachtwoord:</label>
                <input type="password" id="password" name="password" required>
            </div>
            
            <div class="buttons">
                <button type="submit" class="btn-login">Inloggen</button>
                <button type="reset" class="btn-reset">Reset</button>
            </div>
        </form>
        
        <div class="register-link">
            Nog geen account? <a href="registreer.php">Registreer hier</a>
        </div>
    </div>
</body>
</html>