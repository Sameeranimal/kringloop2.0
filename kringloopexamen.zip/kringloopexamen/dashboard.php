<?php
/*
Versie: 1.0
Datum: 28 januari 2026
Beschrijving: Dashboard home pagina na inloggen
*/
 
require_once 'config.php';
require_once 'classes/Database.php';
require_once 'classes/User.php';
 
$database = new Database();
$user = new User($database);
 
// Check of gebruiker ingelogd is
if(!$user->isIngelogd()) {
    header('Location: index.php');
    exit();
}
 
// Haal gebruikersnaam op
$username = $_SESSION['username'];
$rol = $_SESSION['rol'];
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Kringloop Centrum Duurzaam</title>
</head>
<body>
    <nav class="navbar">
        <h1>Kringloop Centrum Duurzaam</h1>
        <div class="navbar-right">
            <div class="user-info">
                <span>Welkom, <?php echo $username; ?>!</span>
                <small>Rol: <?php echo ucfirst($rol); ?></small>
            </div>
            <a href="logout.php" class="btn-logout">Uitloggen</a>
        </div>
    </nav>
    
    <div class="container">
        <div class="welcome-box">
            <h2>Welkom bij je Dashboard</h2>
            <p>Klik op een module om te starten</p>
        </div>
        
        <div class="modules">
            <div class="module-card">
                <a href="modules/voorraad.php">
                    <div class="module-icon"></div>
                    <h3>Voorraad beheer</h3>
                    <p>Artikelen toevoegen en bekijken</p>
                </a>
            </div>
            
            <div class="module-card">
                <a href="modules/klanten.php">
                    <div class="module-icon"></div>
                    <h3>Klanten beheer</h3>
                    <p>Klanten toevoegen en bewerken</p>
                </a>
            </div>
            
            <div class="module-card">
                <a href="modules/categorieen.php">
                    <div class="module-icon"></div>
                    <h3>Categorieën</h3>
                    <p>Artikel categorieën beheren</p>
                </a>
            </div>
            
            <div class="module-card">
                <a href="modules/verkopen.php">
                    <div class="module-icon"></div>
                    <h3>Verkopen</h3>
                    <p>Artikelen verkopen</p>
                </a>
            </div>
            
            <div class="module-card">
                <a href="modules/planning.php">
                    <div class="module-icon"></div>
                    <h3>Planning</h3>
                    <p>Ritten plannen</p>
                </a>
            </div>
            
            <div class="module-card">
                <a href="modules/admin.php">
                    <div class="module-icon"></div>
                    <h3>Admin</h3>
                    <p>Gebruikers beheren</p>
                </a>
            </div>
        </div>
    </div>
</body>
</html>