<?php
/*
Versie: 1.0
Datum: 28-01-2026
Beschrijving: Artikel class voor voorraad beheer
*/

require_once '../config.php';
require_once '../classes/Database.php';
require_once '../classes/User.php';
require_once '../classes/Categorie.php';
 
$database = new Database();
$user = new User($database);
$categorie = new Categorie($database);
 
if(!$user->isIngelogd()) {
    header('Location: ../index.php');
    exit();
}
 
$bericht = "";
$succes = false;
 
// Toevoegen
if(isset($_POST['toevoegen'])) {
    $resultaat = $categorie->toevoegen($_POST['naam']);
    if($resultaat === true) {
        $bericht = "Categorie toegevoegd!";
        $succes = true;
    } else {
        $bericht = $resultaat;
    }
}
 
// Verwijderen
if(isset($_GET['verwijder'])) {
    $resultaat = $categorie->verwijderen($_GET['verwijder']);
    if($resultaat === true) {
        $bericht = "Categorie verwijderd!";
        $succes = true;
    } else {
        $bericht = $resultaat;
    }
}
 
$categorieen = $categorie->ophalen();
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categorieën - Kringloop Centrum</title>
</head>
<body>
    <nav class="navbar">
        <h1>Categorieën Beheer</h1>
        <a href="../dashboard.php">← Terug naar Dashboard</a>
    </nav>
    
    <div class="container">
        <?php if($bericht): ?>
            <div class="<?php echo $succes ? 'success' : 'error'; ?>"><?php echo $bericht; ?></div>
        <?php endif; ?>
        
        <div class="card">
            <h2>Nieuwe Categorie Toevoegen</h2>
            <form method="POST">
                <div class="form-group">
                    <label>Categorie Naam:</label>
                    <input type="text" name="naam" required>
                </div>
                <button type="submit" name="toevoegen" class="btn btn-primary">Toevoegen</button>
            </form>
        </div>
        
        <div class="card">
            <h2>Alle Categorieën</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Naam</th>
                        <th>Acties</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($categorieen as $cat): ?>
                    <tr>
                        <td><?php echo $cat['id']; ?></td>
                        <td><?php echo $cat['naam']; ?></td>
                        <td>
                            <a href="?verwijder=<?php echo $cat['id']; ?>" 
                               class="btn btn-danger" 
                               onclick="return confirm('Weet je het zeker?')">Verwijder</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>