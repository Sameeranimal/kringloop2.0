<?php
/*
Versie: 1.0
Datum: 28 januari 2026
Beschrijving: Planning pagina voor ritten
*/

require_once '../config.php';
require_once '../classes/Database.php';
require_once '../classes/User.php';
require_once '../classes/Planning.php';
require_once '../classes/Klant.php';
require_once '../classes/Artikel.php';

$database = new Database();
$user = new User($database);
$planning = new Planning($database);
$klant = new Klant($database);
$artikel = new Artikel($database);

if(!$user->isIngelogd()) {
    header('Location: ../index.php');
    exit();
}

$bericht = "";
$succes = false;

// Toevoegen
if(isset($_POST['toevoegen'])) {
    $resultaat = $planning->toevoegen(
        $_POST['klant_id'],
        $_POST['artikel_id'],
        $_POST['kenteken'],
        $_POST['ophalen_bezorgen'],
        $_POST['afspraak_op']
    );
    if($resultaat === true) {
        $bericht = "Planning toegevoegd!";
        $succes = true;
    } else {
        $bericht = $resultaat;
    }
}

// Verwijderen
if(isset($_GET['verwijder'])) {
    $resultaat = $planning->verwijderen($_GET['verwijder']);
    if($resultaat === true) {
        $bericht = "Planning verwijderd!";
        $succes = true;
    } else {
        $bericht = $resultaat;
    }
}

$planningen = $planning->ophalen();
$klanten = $klant->ophalen();
$artikelen = $artikel->ophalen();
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Planning - Kringloop Centrum</title>
</head>
<body>
    <nav class="navbar">
        <h1>Planning (Ritten)</h1>
        <a href="../dashboard.php">← Terug naar Dashboard</a>
    </nav>
    
    <div class="container">
        <?php if($bericht): ?>
            <div class="<?php echo $succes ? 'success' : 'error'; ?>"><?php echo $bericht; ?></div>
        <?php endif; ?>
        
        <div class="card">
            <h2>Nieuwe Rit Plannen</h2>
            <form method="POST">
                <div class="form-group">
                    <label>Klant:*</label>
                    <select name="klant_id" required>
                        <option value="">-- Selecteer Klant --</option>
                        <?php foreach($klanten as $k): ?>
                            <option value="<?php echo $k['id']; ?>"><?php echo $k['naam']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Artikel:*</label>
                    <select name="artikel_id" required>
                        <option value="">-- Selecteer Artikel --</option>
                        <?php foreach($artikelen as $art): ?>
                            <option value="<?php echo $art['id']; ?>"><?php echo $art['naam']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Kenteken:</label>
                    <input type="text" name="kenteken" placeholder="XX-XX-XX">
                </div>
                <div class="form-group">
                    <label>Type:*</label>
                    <select name="ophalen_bezorgen" required>
                        <option value="">-- Selecteer --</option>
                        <option value="ophalen">Ophalen</option>
                        <option value="bezorgen">Bezorgen</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Afspraak Datum/Tijd:*</label>
                    <input type="datetime-local" name="afspraak_op" required>
                </div>
                <button type="submit" name="toevoegen" class="btn btn-primary">Planning Toevoegen</button>
            </form>
        </div>
        
        <div class="card">
            <h2>Alle Geplande Ritten</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Klant</th>
                        <th>Artikel</th>
                        <th>Kenteken</th>
                        <th>Type</th>
                        <th>Afspraak</th>
                        <th>Acties</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($planningen as $p): ?>
                    <tr>
                        <td><?php echo $p['id']; ?></td>
                        <td><?php echo $p['klant_naam']; ?></td>
                        <td><?php echo $p['artikel_naam']; ?></td>
                        <td><?php echo $p['kenteken']; ?></td>
                        <td><?php echo ucfirst($p['ophalen_bezorgen']); ?></td>
                        <td><?php echo date('d-m-Y H:i', strtotime($p['afspraak_op'])); ?></td>
                        <td>
                            <a href="?verwijder=<?php echo $p['id']; ?>" 
                               class="btn btn-danger" 
                               onclick="return confirm('Weet je het zeker?')">Verwijder</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>