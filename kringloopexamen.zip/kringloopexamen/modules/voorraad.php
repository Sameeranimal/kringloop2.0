<?php
/*
Versie: 1.0
Datum: 28 januari 2026
Beschrijving: Voorraad beheer pagina (artikelen)
*/

require_once '../config.php';
require_once '../classes/Database.php';
require_once '../classes/User.php';
require_once '../classes/Artikel.php';
require_once '../classes/Categorie.php';

$database = new Database();
$user = new User($database);
$artikel = new Artikel($database);
$categorie = new Categorie($database);

if(!$user->isIngelogd()) {
    header('Location: ../index.php');
    exit();
}

$bericht = "";
$succes = false;

// Toevoegen
if(isset($_POST['toevoegen'])) {
    $resultaat = $artikel->toevoegen(
        $_POST['categorie_id'], 
        $_POST['naam'], 
        $_POST['prijs'], 
        $_POST['aantal']
    );
    if($resultaat === true) {
        $bericht = "Artikel toegevoegd!";
        $succes = true;
    } else {
        $bericht = $resultaat;
    }
}

// Verwijderen
if(isset($_GET['verwijder'])) {
    $resultaat = $artikel->verwijderen($_GET['verwijder']);
    if($resultaat === true) {
        $bericht = "Artikel verwijderd!";
        $succes = true;
    } else {
        $bericht = $resultaat;
    }
}

$artikelen = $artikel->ophalen();
$categorieen = $categorie->ophalen();
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voorraad - Kringloop Centrum</title>
</head>
<body>
    <nav class="navbar">
        <h1>Voorraad Beheer</h1>
        <a href="../dashboard.php">← Terug naar Dashboard</a>
    </nav>
    
    <div class="container">
        <?php if($bericht): ?>
            <div class="<?php echo $succes ? 'success' : 'error'; ?>"><?php echo $bericht; ?></div>
        <?php endif; ?>
        
        <div class="card">
            <h2>Nieuw Artikel Toevoegen</h2>
            <form method="POST">
                <div class="form-group">
                    <label>Categorie:*</label>
                    <select name="categorie_id" required>
                        <option value="">-- Selecteer --</option>
                        <?php foreach($categorieen as $cat): ?>
                            <option value="<?php echo $cat['id']; ?>"><?php echo $cat['naam']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Artikel Naam:*</label>
                    <input type="text" name="naam" required>
                </div>
                <div class="form-group">
                    <label>Prijs (€):*</label>
                    <input type="number" name="prijs" step="0.01" min="0" required>
                </div>
                <div class="form-group">
                    <label>Aantal:*</label>
                    <input type="number" name="aantal" min="1" value="1" required>
                </div>
                <button type="submit" name="toevoegen" class="btn btn-primary">Toevoegen</button>
            </form>
        </div>
        
        <div class="card">
            <h2>Alle Artikelen</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Naam</th>
                        <th>Categorie</th>
                        <th>Prijs</th>
                        <th>Aantal</th>
                        <th>Acties</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($artikelen as $art): ?>
                    <tr>
                        <td><?php echo $art['id']; ?></td>
                        <td><?php echo $art['naam']; ?></td>
                        <td><?php echo $art['categorie_naam']; ?></td>
                        <td>€ <?php echo number_format($art['prijs'], 2, ',', '.'); ?></td>
                        <td><?php echo $art['aantal']; ?></td>
                        <td>
                            <a href="?verwijder=<?php echo $art['id']; ?>" 
                               class="btn btn-danger" 
                               onclick="return confirm('Weet je het zeker?')">Verwijder</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>