<?php
/*
Versie: 1.0
Datum: 28 januari 2026
Beschrijving: Klanten beheer pagina
*/

require_once '../config.php';
require_once '../classes/Database.php';
require_once '../classes/User.php';
require_once '../classes/Klant.php';

$database = new Database();
$user = new User($database);
$klant = new Klant($database);

if(!$user->isIngelogd()) {
    header('Location: ../index.php');
    exit();
}

$bericht = "";
$succes = false;

// Toevoegen
if(isset($_POST['toevoegen'])) {
    $resultaat = $klant->toevoegen(
        $_POST['naam'], 
        $_POST['adres'], 
        $_POST['plaats'], 
        $_POST['telefoon'], 
        $_POST['email']
    );
    if($resultaat === true) {
        $bericht = "Klant toegevoegd!";
        $succes = true;
    } else {
        $bericht = $resultaat;
    }
}

// Verwijderen
if(isset($_GET['verwijder'])) {
    $resultaat = $klant->verwijderen($_GET['verwijder']);
    if($resultaat === true) {
        $bericht = "Klant verwijderd!";
        $succes = true;
    } else {
        $bericht = $resultaat;
    }
}

$klanten = $klant->ophalen();
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Klanten - Kringloop Centrum</title>
</head>
<body>
    <nav class="navbar">
        <h1>Klanten Beheer</h1>
        <a href="../dashboard.php">← Terug naar Dashboard</a>
    </nav>
   
    <div class="container">
        <?php if($bericht): ?>
            <div class="<?php echo $succes ? 'success' : 'error'; ?>"><?php echo $bericht; ?></div>
        <?php endif; ?>
       
        <div class="card">
            <h2>Nieuwe Klant Toevoegen</h2>
            <form method="POST">
                <div class="form-group">
                    <label>Naam:*</label>
                    <input type="text" name="naam" required>
                </div>
                <div class="form-group">
                    <label>Adres:</label>
                    <input type="text" name="adres">
                </div>
                <div class="form-group">
                    <label>Plaats:</label>
                    <input type="text" name="plaats">
                </div>
                <div class="form-group">
                    <label>Telefoon:</label>
                    <input type="text" name="telefoon">
                </div>
                <div class="form-group">
                    <label>Email:</label>
                    <input type="email" name="email">
                </div>
                <button type="submit" name="toevoegen" class="btn btn-primary">Toevoegen</button>
            </form>
        </div>
       
        <div class="card">
            <h2>Alle Klanten</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Naam</th>
                        <th>Adres</th>
                        <th>Plaats</th>
                        <th>Telefoon</th>
                        <th>Email</th>
                        <th>Acties</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($klanten as $k): ?>
                    <tr>
                        <td><?php echo $k['id']; ?></td>
                        <td><?php echo $k['naam']; ?></td>
                        <td><?php echo $k['adres']; ?></td>
                        <td><?php echo $k['plaats']; ?></td>
                        <td><?php echo $k['telefoon']; ?></td>
                        <td><?php echo $k['email']; ?></td>
                        <td>
                            <a href="?verwijder=<?php echo $k['id']; ?>"
                               class="btn btn-danger"
                               onclick="return confirm('Weet je het zeker?')">Verwijder</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
 