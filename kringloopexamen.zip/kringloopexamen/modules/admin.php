 <?php
/*
Versie: 1.0
Datum: 28-01-2026
Beschrijving: Artikel class voor voorraad beheer
*/

require_once '../config.php';
require_once '../classes/Database.php';
require_once '../classes/User.php';
 
$database = new Database();
$user = new User($database);
 
if(!$user->isIngelogd()) {
    header('Location: ../index.php');
    exit();
}
 
$bericht = "";
$succes = false;
 
// Registreer nieuwe gebruiker (alleen admin)
if(isset($_POST['registreer']) && $_SESSION['rol'] == 'admin') {
    $resultaat = $user->registreer($_POST['username'], $_POST['password']);
    if($resultaat === true) {
        $bericht = "Gebruiker toegevoegd!";
        $succes = true;
    } else {
        $bericht = $resultaat;
    }
}
 
// Haal alle gebruikers op
$sql = "SELECT id, username, rol, gemaakt_op FROM gebruiker ORDER BY id DESC";
$stmt = $database->getVerbinding()->prepare($sql);
$stmt->execute();
$gebruikers = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Kringloop Centrum</title>
</head>
<body>
    <nav class="navbar">
        <h1>Admin Paneel</h1>
        <a href="../dashboard.php">← Terug naar Dashboard</a>
    </nav>
   
    <div class="container">
        <?php if($bericht): ?>
            <div class="<?php echo $succes ? 'success' : 'error'; ?>"><?php echo $bericht; ?></div>
        <?php endif; ?>
       
        <?php if($_SESSION['rol'] == 'admin'): ?>
        <div class="card">
            <h2>Nieuwe Gebruiker Toevoegen</h2>
            <form method="POST">
                <div class="form-group">
                    <label>Gebruikersnaam:*</label>
                    <input type="text" name="username" required minlength="3">
                </div>
                <div class="form-group">
                    <label>Wachtwoord:*</label>
                    <input type="password" name="password" required minlength="6">
                </div>
                <button type="submit" name="registreer" class="btn btn-primary">Gebruiker Toevoegen</button>
            </form>
        </div>
        <?php endif; ?>