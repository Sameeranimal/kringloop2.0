<?php
/*
Versie: 1.0
Datum: 28 januari 2026
Beschrijving: Registratiepagina voor nieuwe gebruikers.
*/

require_once 'config.php';
require_once 'classes/Database.php';
require_once 'classes/User.php';

$database = new Database();
$user = new User($database);

if($user->isIngelogd()) {
    header('Location: dashboard.php');
    exit();
}

$bericht = "";
$succes = false;

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $rol = $_POST['rol'];
    
    $resultaat = $user->registreer($username, $password, $rol);
    
    if($resultaat === true) {
        $bericht = "Account aangemaakt! Je kan nu inloggen.";
        $succes = true;
    } else {
        $bericht = $resultaat;
    }
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registreren - Kringloop Centrum Duurzaam</title>
</head>
<body>
    <div class="register-container">
        <div class="logo">
            <h1>Kringloop Centrum Duurzaam</h1>
            <p>Nieuw account aanmaken</p>
        </div>
        
        <?php if($bericht && !$succes): ?>
            <div class="error"><?php echo $bericht; ?></div>
        <?php endif; ?>
        
        <?php if($succes): ?>
            <div class="success"><?php echo $bericht; ?></div>
        <?php endif; ?>
        
        <?php if(!$succes): ?>
        <form method="POST" action="">
            <div class="form-group">
                <label for="username">Gebruikersnaam:</label>
                <input type="text" id="username" name="username" required minlength="3">
                <small style="color: #7f8c8d;">Minimaal 3 tekens</small>
            </div>
            
            <div class="form-group">
                <label for="password">Wachtwoord:</label>
                <input type="password" id="password" name="password" required minlength="6">
                <small style="color: #7f8c8d;">Minimaal 6 tekens</small>
            </div>
            
            <div class="form-group">
                <label for="rol">Rol:</label>
                <select id="rol" name="rol" required style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 5px; font-size: 14px;">
                    <option value="medewerker">Medewerker</option>
                    <option value="admin">Admin</option>
                </select>
                <small style="color: #7f8c8d;">Kies je rol in het systeem</small>
            </div>
            
            <div class="buttons">
                <button type="submit" class="btn-register">Registreren</button>
                <button type="reset" class="btn-reset">Reset</button>
            </div>
        </form>
        <?php endif; ?>
        
        <div class="login-link">
            Al een account? <a href="index.php">Log hier in</a>
        </div>
    </div>
</body>
</html>
