<?php
/*
Versie: 1.0
Datum: 28 januari 2026
Beschrijving: Uitlogpagina voor gebruikers.
*/

session_start();
session_destroy();
header('Location: index.php');
exit();
?> 