<?php
/*
Versie: 1.0
Datum: 28 januari 2026
Beschrijving: Configuratie bestand met database gegevens
*/
 
// Database instellingen
define('DB_HOST', 'localhost');
define('DB_NAME', 'centrum_duurzaam');
define('DB_USER', 'root');
define('DB_PASS', '');
 
// Start sessie voor inloggen
session_start();
?>