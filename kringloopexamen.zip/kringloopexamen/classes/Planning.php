<?php
/*
Versie: 1.0
Datum: 28-01-2026
Beschrijving: Planning class voor ritten planning
*/

class Planning {
    
    public $database;
    
    public function __construct($database) {
        $this->database = $database;
    }
    
    public function toevoegen($klant_id, $artikel_id, $kenteken, $ophalen_bezorgen, $afspraak_op) {
        if(empty($klant_id) || empty($artikel_id) || empty($afspraak_op)) {
            return "Vul alle verplichte velden in";
        }
        
        $sql = "INSERT INTO planning (klant_id, artikel_id, kenteken, ophalen_bezorgen, afspraak_op) 
                VALUES (:klant_id, :artikel_id, :kenteken, :ophalen_bezorgen, :afspraak_op)";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->bindParam(':klant_id', $klant_id);
        $stmt->bindParam(':artikel_id', $artikel_id);
        $stmt->bindParam(':kenteken', $kenteken);
        $stmt->bindParam(':ophalen_bezorgen', $ophalen_bezorgen);
        $stmt->bindParam(':afspraak_op', $afspraak_op);
        
        if($stmt->execute()) {
            return true;
        }
        return "Planning toevoegen mislukt";
    }
    
    public function ophalen() {
        $sql = "SELECT planning.*, klant.naam as klant_naam, artikel.naam as artikel_naam 
                FROM planning 
                JOIN klant ON planning.klant_id = klant.id 
                JOIN artikel ON planning.artikel_id = artikel.id 
                ORDER BY planning.afspraak_op DESC";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function verwijderen($id) {
        $sql = "DELETE FROM planning WHERE id = :id";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->bindParam(':id', $id);
        
        if($stmt->execute()) {
            return true;
        }
        return "Verwijderen mislukt";
    }
}
?>
