<?php
/*
Versie: 1.0
Datum: 28-01-2026
Beschrijving: Verkoop class voor verkopen beheer
*/

class Verkoop {
    
    public $database;
    
    public function __construct($database) {
        $this->database = $database;
    }
    
    public function verkopen($klant_id, $artikel_id) {
        if(empty($klant_id) || empty($artikel_id)) {
            return "Selecteer een klant en artikel";
        }
        
        // Check of artikel beschikbaar is
        $sql = "SELECT aantal FROM artikel WHERE id = :artikel_id";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->bindParam(':artikel_id', $artikel_id);
        $stmt->execute();
        $artikel = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if($artikel['aantal'] <= 0) {
            return "Artikel niet op voorraad";
        }
        
        // Verkoop toevoegen
        $sql = "INSERT INTO verkopen (klant_id, artikel_id) VALUES (:klant_id, :artikel_id)";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->bindParam(':klant_id', $klant_id);
        $stmt->bindParam(':artikel_id', $artikel_id);
        
        if($stmt->execute()) {
            // Aantal artikel verminderen
            $sql = "UPDATE artikel SET aantal = aantal - 1 WHERE id = :artikel_id";
            $stmt = $this->database->getVerbinding()->prepare($sql);
            $stmt->bindParam(':artikel_id', $artikel_id);
            $stmt->execute();
            
            return true;
        }
        return "Verkoop mislukt";
    }
    
    public function ophalen() {
        $sql = "SELECT verkopen.*, klant.naam as klant_naam, artikel.naam as artikel_naam, artikel.prijs 
                FROM verkopen 
                JOIN klant ON verkopen.klant_id = klant.id 
                JOIN artikel ON verkopen.artikel_id = artikel.id 
                ORDER BY verkopen.verkocht_op DESC";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
