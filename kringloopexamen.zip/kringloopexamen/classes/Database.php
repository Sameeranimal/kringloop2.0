<?php
/*
Versie: 1.0
Datum: 28-01-2026
Beschrijving: Database class voor verbinding met MySQL via PDO
*/

class Database {
    
    public $verbinding;
    
    public function __construct() {
        $this->maakVerbinding();
    }
    
    public function maakVerbinding() {
        try {
            $this->verbinding = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME,
                DB_USER,
                DB_PASS
            );
            $this->verbinding->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $e) {
            die("Database verbinding mislukt: " . $e->getMessage());
        }
    }
    
    public function getVerbinding() {
        return $this->verbinding;
    }
}
?>
