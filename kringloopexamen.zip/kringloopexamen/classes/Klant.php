<?php
/*
Versie: 1.0
Datum: 28-01-2026
Beschrijving: Klant class voor klanten beheer
*/

class Klant {
    
    public $database;
    public $id;
    public $naam;
    public $adres;
    public $plaats;
    public $telefoon;
    public $email;
    
    public function __construct($database) {
        $this->database = $database;
    }
    
    public function toevoegen($naam, $adres, $plaats, $telefoon, $email) {
        if(empty($naam)) {
            return "Vul een naam in";
        }
        
        $sql = "INSERT INTO klant (naam, adres, plaats, telefoon, email) VALUES (:naam, :adres, :plaats, :telefoon, :email)";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->bindParam(':naam', $naam);
        $stmt->bindParam(':adres', $adres);
        $stmt->bindParam(':plaats', $plaats);
        $stmt->bindParam(':telefoon', $telefoon);
        $stmt->bindParam(':email', $email);
        
        if($stmt->execute()) {
            return true;
        }
        return "Klant toevoegen mislukt";
    }
    
    public function ophalen() {
        $sql = "SELECT * FROM klant ORDER BY naam";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function ophaalEnkele($id) {
        $sql = "SELECT * FROM klant WHERE id = :id";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function verwijderen($id) {
        $sql = "DELETE FROM klant WHERE id = :id";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->bindParam(':id', $id);
        
        if($stmt->execute()) {
            return true;
        }
        return "Verwijderen mislukt";
    }
    
    public function bewerken($id, $naam, $adres, $plaats, $telefoon, $email) {
        if(empty($naam)) {
            return "Vul een naam in";
        }
        
        $sql = "UPDATE klant SET naam = :naam, adres = :adres, plaats = :plaats, telefoon = :telefoon, email = :email WHERE id = :id";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->bindParam(':naam', $naam);
        $stmt->bindParam(':adres', $adres);
        $stmt->bindParam(':plaats', $plaats);
        $stmt->bindParam(':telefoon', $telefoon);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':id', $id);
        
        if($stmt->execute()) {
            return true;
        }
        return "Bewerken mislukt";
    }
}
?>
