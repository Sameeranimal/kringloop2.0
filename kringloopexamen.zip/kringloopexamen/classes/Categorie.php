<?php
/*
Versie: 1.0
Datum: 28-01-2026
Beschrijving: Categorie class voor categorie beheer
*/

class Categorie {
    
    public $database;
    public $id;
    public $naam;
    
    public function __construct($database) {
        $this->database = $database;
    }
    
    public function toevoegen($naam) {
        if(empty($naam)) {
            return "Vul een naam in";
        }
        
        $sql = "INSERT INTO categorie (naam) VALUES (:naam)";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->bindParam(':naam', $naam);
        
        if($stmt->execute()) {
            return true;
        }
        return "Categorie toevoegen mislukt";
    }
    
    public function ophalen() {
        $sql = "SELECT * FROM categorie ORDER BY naam";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function verwijderen($id) {
        $sql = "DELETE FROM categorie WHERE id = :id";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->bindParam(':id', $id);
        
        if($stmt->execute()) {
            return true;
        }
        return "Verwijderen mislukt";
    }
    
    public function bewerken($id, $naam) {
        if(empty($naam)) {
            return "Vul een naam in";
        }
        
        $sql = "UPDATE categorie SET naam = :naam WHERE id = :id";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->bindParam(':naam', $naam);
        $stmt->bindParam(':id', $id);
        
        if($stmt->execute()) {
            return true;
        }
        return "Bewerken mislukt";
    }
}
?>
