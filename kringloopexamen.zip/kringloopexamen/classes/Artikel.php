<?php
/*
Versie: 1.0
Datum: 28-01-2026
Beschrijving: Artikel class voor voorraad beheer
*/

class Artikel {
    
    public $database;
    public $id;
    public $categorie_id;
    public $naam;
    public $prijs;
    public $aantal;
    
    public function __construct($database) {
        $this->database = $database;
    }
    
    public function toevoegen($categorie_id, $naam, $prijs, $aantal) {
        if(empty($naam) || empty($prijs)) {
            return "Vult alle verplichte velden in";
        }
        
        if($prijs < 0) {
            return "Prijs kan niet negatief zijn";
        }
        
        $sql = "INSERT INTO artikel (categorie_id, naam, prijs, aantal) VALUES (:categorie_id, :naam, :prijs, :aantal)";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->bindParam(':categorie_id', $categorie_id);
        $stmt->bindParam(':naam', $naam);
        $stmt->bindParam(':prijs', $prijs);
        $stmt->bindParam(':aantal', $aantal);
        
        if($stmt->execute()) {
            return true;
        }
        return "Artikel toevoegen mislukt";
    }
    
    public function ophalen() {
        $sql = "SELECT artikel.*, categorie.naam as categorie_naam 
                FROM artikel 
                JOIN categorie ON artikel.categorie_id = categorie.id 
                ORDER BY artikel.naam";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function ophaalEnkele($id) {
        $sql = "SELECT artikel.*, categorie.naam as categorie_naam 
                FROM artikel 
                JOIN categorie ON artikel.categorie_id = categorie.id 
                WHERE artikel.id = :id";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function verwijderen($id) {
        $sql = "DELETE FROM artikel WHERE id = :id";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->bindParam(':id', $id);
        
        if($stmt->execute()) {
            return true;
        }
        return "Verwijderen is mislukt";
    }
    
    public function bewerken($id, $categorie_id, $naam, $prijs, $aantal) {
        if(empty($naam) || empty($prijs)) {
            return "Vult alle verplichte velden in";
        }
        
        if($prijs < 0) {
            return "Prijs kan niet negatief zijn";
        }
        
        $sql = "UPDATE artikel SET categorie_id = :categorie_id, naam = :naam, prijs = :prijs, aantal = :aantal WHERE id = :id";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->bindParam(':categorie_id', $categorie_id);
        $stmt->bindParam(':naam', $naam);
        $stmt->bindParam(':prijs', $prijs);
        $stmt->bindParam(':aantal', $aantal);
        $stmt->bindParam(':id', $id);
        
        if($stmt->execute()) {
            return true;
        }
        return "Bewerken mislukt";
    }
}
?>
