<?php
/*
Versie: 1.0
Datum: 28-01-2026
Beschrijving: User class voor inloggen en registreren
*/

class User {
    
    public $database;
    public $username;
    public $password;
    public $rol;
    
    public function __construct($database) {
        $this->database = $database;
    }
    
    public function registreer($username, $password, $rol = 'medewerker') {
        // Check of velden leeg zijn
        if(empty($username) || empty($password)) {
            return "Vul alle velden in";
        }
        
        // Check username lengte
        if(strlen($username) < 3) {
            return "Username moet minimaal 3 tekens zijn";
        }
        
        // Check password lengte
        if(strlen($password) < 6) {
            return "Wachtwoord moet minimaal 6 tekens zijn";
        }
        
        // Check of username al bestaat
        $sql = "SELECT * FROM gebruiker WHERE username = :username";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        
        if($stmt->rowCount() > 0) {
            return "Username bestaat al";
        }
        
        // Wachtwoord hashen
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        // Gebruiker toevoegen
        $sql = "INSERT INTO gebruiker (username, password, rol) VALUES (:username, :password, :rol)";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':password', $hashed_password);
        $stmt->bindParam(':rol', $rol);
        
        if($stmt->execute()) {
            return true;
        } else {
            return "Registratie mislukt";
        }
    }
    
    public function login($username, $password) {
        // Check of velden leeg zijn
        if(empty($username) || empty($password)) {
            return "Vul alle velden in";
        }
        
        // Zoek gebruiker
        $sql = "SELECT * FROM gebruiker WHERE username = :username";
        $stmt = $this->database->getVerbinding()->prepare($sql);
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        
        if($stmt->rowCount() == 0) {
            return "Gebruiker niet gevonden";
        }
        
        $gebruiker = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Check wachtwoord
        if(password_verify($password, $gebruiker['password'])) {
            // Login gelukt
            $_SESSION['user_id'] = $gebruiker['id'];
            $_SESSION['username'] = $gebruiker['username'];
            $_SESSION['rol'] = $gebruiker['rol'];
            return true;
        } else {
            return "Wachtwoord is verkeerd";
        }
    }
    
    public function isIngelogd() {
        if(isset($_SESSION['user_id'])) {
            return true;
        }
        return false;
    }
}
?>
